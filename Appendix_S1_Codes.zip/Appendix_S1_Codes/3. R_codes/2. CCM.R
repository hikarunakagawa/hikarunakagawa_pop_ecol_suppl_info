setwd("folderpass")

library(parallel)
library(dplyr)
library(tidyr)
library(rEDM)

levels_F<-c("Mean_water_level","Maximum_water_level")
levels_H<-c("Water_depth_SD","Current_velocity_SD","Sand","Granule","Pebble","Cobble","Boulder","Bedrock")
levels_S<-c("Andrias_japonicus","Cynops_pyrrhogaster","Oncorhynchus_masou",
            "Tribolodon_hakonensis","Rhynchocypris_oxycephalus","Nipponocypris_temminckii",
            "Pungtungia_herzi","Pseudogobio_esocinus","Cobitis_sp.",
            "Niwaella_delicata","Liobagrus_reinii","Cottus_pollux",
            "Odontobutis_obscura","Rhinogobius_flumineus")
levels_All<-c(levels_F,levels_H,levels_S)
levels_All<-c(levels_F,levels_H,levels_S)

levels_season<-c("December-January","February-March","April-May","June-July","August-September","October-November")

data01<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data00<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nhb<-length(levels_H)
nsp<-length(levels_S)

data01<-data01[,levels_F]
data02<-data00[,levels_H]
data03<-data00[,levels_S]

lm01<-apply(data01,2,function(x){lm(x~c(1:length(x)))})
lm02<-apply(data02,2,function(x){lm(x~c(1:length(x)))})
lm03<-apply(data03,2,function(x){lm(x~c(1:length(x)))})

for(i in 1:ncol(data01)){if(summary(lm01[[i]])$coefficients[2,4]<0.05)data01[,i]<-residuals(lm01[[i]])}
for(i in 1:ncol(data02)){if(summary(lm02[[i]])$coefficients[2,4]<0.05)data02[,i]<-residuals(lm02[[i]])}
for(i in 1:ncol(data03)){if(summary(lm03[[i]])$coefficients[2,4]<0.05)data03[,i]<-residuals(lm03[[i]])}

data01<-as.data.frame(apply(data01,2,scale))
data02<-as.data.frame(apply(data02,2,scale))
data03<-as.data.frame(apply(data03,2,scale))

#Optimal embedding dimensions
simplex2<-function(d01){
  Ey<-rep(NA,ncol(d01))
  thetay<-rep(NA,ncol(d01))
  for(s in 1:ncol(d01)){
    d <- d01[,s]
    simp_res<-simplex(d,E=1:15)
    E0<-as.numeric(simp_res$E)
    rmse0<-as.numeric(simp_res$rmse)
    p_val0<-as.numeric(simp_res$p_val)
    tau0<-as.factor(simp_res$tau)
    Ey[s] <- simp_res$E[which(rmse0==min(rmse0[complete.cases(p_val0)]))]
    smap_res2 <- s_map(d,E=Ey[s],silent=T)
    rmse0<-as.numeric(smap_res2$rmse)
    p_val0<-as.numeric(smap_res2$p_val)
    thetay[s]<-smap_res2$theta[which(rmse0==min(rmse0[complete.cases(p_val0)]))]
  }
  data.frame(species=colnames(d01),E=Ey,theta=thetay)
}

params0<-simplex2(data01)
params1<-simplex2(data02)
params2<-simplex2(data03)
write.csv(params0,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/Embedding_hydrologicals.csv",sep=""),row.names=FALSE)
write.csv(params1,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/Embedding_habitats.csv",sep=""),row.names=FALSE)
write.csv(params2,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/Embedding_vertebrates.csv",sep=""),row.names=FALSE)

#CCM
data_ccm<-function(d01,d02,params01){
  data_rho<-list()
  k<-0
  for(s1 in c(1:ncol(d02))){
    for(s2 in c(1:ncol(d01))){
      d<-cbind(d02[,s1],d01[,s2])
      libsize1<-c(params01$E[s1]+c(1,2),nrow(d)-(params01$E[s1]))
      n_surr<-100
      x1_surr<-make_surrogate_data(d[,1],method="seasonal",num_surr=n_surr,T_period=6)
      x2_surr<-make_surrogate_data(d[,2],method="seasonal",num_surr=n_surr,T_period=6)
      ccm_all_res <- ccm(d,E=params01$E[s1],
                         lib_sizes = libsize1,
                         stats_only = FALSE)
      ccm_pred<-ccm_all_res$CCM1_PredictStat
      rho1<-apply(matrix(ccm_pred$rho,ncol=length(libsize1)),2,quantile,probs=c(0.05,0.5,0.95))
      out1<-max(rho1[,2])<min(rho1[,length(libsize1)])
      if(out1){
        ccm_surr<-mclapply(1:n_surr, function(p) {
          ccm_surr0<-ccm(cbind(x1_surr[,p],x2_surr[,p]),
                         E=params01$E[s1],
                         lib_sizes = libsize1,
                         stats_only =TRUE)
          return(ccm_surr0$"X1:X2")
        }, mc.cores = 4)
        ccm_surr<-do.call(rbind,ccm_surr)
        rho2<-apply(ccm_surr,2,quantile,probs=c(0.05,0.5,0.95))
        out2<-max(rho2[,length(libsize1)])<min(rho1[,length(libsize1)])
        if(out2){
          k<-k+1
          rho12<-cbind(rho1[,-1],rho2[,-1])
          data_rho[[k]]<-data.frame(To=colnames(d02)[s1],From=colnames(d01)[s2],LibSize=rep(libsize1[-1],2),surr=rep(c("obs","surr"),each=length(libsize1[-1])),lower=rho12[1,],median=rho12[2,],upper=rho12[3,])
        }
      }
    }
  }
  ifelse(length(data_rho)==0,data_rho<-data.frame(To=NA,From=NA,LibSize=NA,surr=NA,lower=NA,median=NA,upper=NA),data_rho<-do.call(rbind,data_rho))
  data_rho
}

data_rho_HF<-data_ccm(data01,data02,params1)
data_rho_SF<-data_ccm(data01,data03,params2)
data_rho_SH<-data_ccm(data02,data03,params2)
write.csv(data_rho_HF,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_habitats_hydrologicals.csv",sep=""),row.names=FALSE)
write.csv(data_rho_SF,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_vertebrates_hydrologicals.csv",sep=""),row.names=FALSE)
write.csv(data_rho_SH,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_vertebrates_habitats.csv",sep=""),row.names=FALSE)

#CCM between vertebrates
data_rho<-list()
k<-0
for(s1 in c(1:ncol(data03))){
  v<-c(1:ncol(data03))[-s1]
  for(s2 in v){
    d<-data03[,c(s1,s2)]
    libsize1<-c(params2$E[s1]+c(1,2),nrow(d)-(params2$E[s1]))
    n_surr<-100
    x1_surr<-make_surrogate_data(d[,1],method="seasonal",num_surr=n_surr,T_period=6)
    x2_surr<-make_surrogate_data(d[,2],method="seasonal",num_surr=n_surr,T_period=6)
    ccm_all_res <- ccm(d,
                       E=params2$E[s1],
                       lib_sizes = libsize1,
                       stats_only = FALSE)
    ccm_pred<-ccm_all_res$CCM1_PredictStat
    
    rho1<-apply(matrix(ccm_pred$rho,ncol=length(libsize1)),2,quantile,probs=c(0.05,0.5,0.95))
    out1<-max(rho1[,2])<min(rho1[,length(libsize1)])
    if(out1){
      ccm_surr<-mclapply(1:n_surr, function(p) {
        ccm_surr0<-ccm(cbind(x1_surr[,p],x2_surr[,p]),
                       E=params2$E[s1],
                       lib_sizes = libsize1,
                       stats_only =TRUE)
        return(ccm_surr0$"X1:X2")
      }, mc.cores = 4)
      ccm_surr<-do.call(rbind,ccm_surr)
      rho2<-apply(ccm_surr,2,quantile,probs=c(0.05,0.5,0.95))
      out2<-max(rho2[,length(libsize1)])<min(rho1[,length(libsize1)])
      if(out2){
        k<-k+1
        rho12<-cbind(rho1[,-1],rho2[,-1])
        data_rho[[k]]<-data.frame(To=colnames(data03)[s1],From=colnames(data03)[s2],LibSize=rep(libsize1[-1],2),surr=rep(c("obs","surr"),each=length(libsize1[-1])),lower=rho12[1,],median=rho12[2,],upper=rho12[3,])
      }
    }
  }
}

ifelse(length(data_rho)==0,data_rho<-data.frame(To=NA,From=NA,LibSize=NA,surr=NA,lower=NA,median=NA,upper=NA),data_rho<-do.call(rbind,data_rho))
write.csv(data_rho,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_vertebrates.csv",sep=""),row.names=FALSE)

#Unrealistic causation passes
data_rho_FH<-data_ccm(data02,data.frame(data01[,levels_F[2]]),params0)
data_rho_FS<-data_ccm(data03,data.frame(data01[,levels_F[2]]),params0)
write.csv(data_rho_FH,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_maximumWaterLevel_habitats.csv",sep=""),row.names=FALSE)
write.csv(data_rho_FS,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_maximumWaterLevel_vertebrates.csv",sep=""),row.names=FALSE)
