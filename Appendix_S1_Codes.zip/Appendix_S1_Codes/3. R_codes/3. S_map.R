setwd("folderpass")

library(parallel)
library(dplyr)
library(tidyr)
library(rEDM)

levels_F<-c("Mean_water_level","Maximum_water_level")
levels_H<-c("Water_depth_SD","Current_velocity_SD","Sand","Granule","Pebble","Cobble","Boulder","Bedrock")
levels_S<-c("Andrias_japonicus","Cynops_pyrrhogaster","Oncorhynchus_masou",
            "Tribolodon_hakonensis","Rhynchocypris_oxycephalus","Nipponocypris_temminckii",
            "Pungtungia_herzi","Pseudogobio_esocinus","Cobitis_sp.",
            "Niwaella_delicata","Liobagrus_reinii","Cottus_pollux",
            "Odontobutis_obscura","Rhinogobius_flumineus")
levels_All<-c(levels_F,levels_H,levels_S)
levels_All<-c(levels_F,levels_H,levels_S)

levels_season<-c("December-January","February-March","April-May","June-July","August-September","October-November")

data01<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data00<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nhb<-length(levels_H)
nsp<-length(levels_S)

data01<-data01[,levels_F]
data02<-data00[,levels_H]
data03<-data00[,levels_S]

lm01<-apply(data01,2,function(x){lm(x~c(1:length(x)))})
lm02<-apply(data02,2,function(x){lm(x~c(1:length(x)))})
lm03<-apply(data03,2,function(x){lm(x~c(1:length(x)))})

for(i in 1:ncol(data01)){if(summary(lm01[[i]])$coefficients[2,4]<0.05)data01[,i]<-residuals(lm01[[i]])}
for(i in 1:ncol(data02)){if(summary(lm02[[i]])$coefficients[2,4]<0.05)data02[,i]<-residuals(lm02[[i]])}
for(i in 1:ncol(data03)){if(summary(lm03[[i]])$coefficients[2,4]<0.05)data03[,i]<-residuals(lm03[[i]])}

data01<-as.data.frame(apply(data01,2,scale))
data02<-as.data.frame(apply(data02,2,scale))
data03<-as.data.frame(apply(data03,2,scale))

rho01<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/rho_habitats_hydrologicals.csv',sep="")))
rho02<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/rho_vertebrates_hydrologicals.csv',sep="")))
rho03<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/rho_vertebrates_habitats.csv',sep="")))
rho04<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/rho_vertebrates.csv',sep="")))

pairs01<-do.call(rbind,strsplit(unique(paste(rho01$To,rho01$From))," "))
pairs02<-do.call(rbind,strsplit(unique(paste(rho02$To,rho02$From))," "))
pairs03<-do.call(rbind,strsplit(unique(paste(rho03$To,rho03$From))," "))
pairs04<-do.call(rbind,strsplit(unique(paste(rho04$To,rho04$From))," "))

pairs<-rbind(pairs01,pairs02,pairs03,pairs04)
pairs<-pairs[!pairs[,1]=="NA",]
s0<-levels_S[!is.element(levels_S,pairs[,1])]
pairs<-rbind(pairs,cbind(s0,rep(NA,length(s0))))

params1<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/Embedding_habitats.csv',sep="")))
params2<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/Embedding_vertebrates.csv',sep="")))
params<-rbind(params1,params2)

f_block<-function(x1,x2,E0){
  s00<-list()
  s0<-names(x2)
  if((E0-1)<length(s0)){
    c0<-combn(c(s0),(E0-1))
    for(i in 1:ncol(c0)){
      s00[[i]]<-c(c0[,i])
    }
  }else{s00[[1]]<-s0}
  d00<-list()
  for(l in 1:length(s00)){
    s000<-s00[[l]]
    d<-make_block(data.frame(t=1:nrow(x1),x1),max_lag=E0-length(s000)+1)
    d0<-data.frame(matrix(NA,nrow(x1)-nrow(d),ncol(d)))
    colnames(d0)<-names(d)
    d<-rbind(d0,d)
    b<-data.frame(x2[-nrow(x2),s000])
    b0<-data.frame(matrix(NA,1,ncol(b)))
    names(b)<-s000
    names(b0)<-s000
    b<-rbind(b0,b)
    d<-cbind(d,b)
    d<-d[complete.cases(d),]
    d00[[l]]<-d
  }
  return(d00)
}

smap.rho<-data.frame(matrix(rep(NA,4),nrow=1))[numeric(0), ]
colnames(smap.rho)<-c("To","From","rho","theta")
d_l<-list()
for(s in 1:length(unique(pairs[,1]))){
  s1<-unique(pairs[,1])[s]
  s2<-unique(pairs[pairs[,1]==s1,2])
  d<-data.frame(cbind(data02,data03)[,s1])
  names(d)<-s1
  d0<-cbind(data01,data02,data03)
  d0<-data.frame(d0[,s2])
  names(d0)<-s2
  E1<-filter(params,species==s1)$E
  d_l0<-f_block(d,d0,E1)
  smap.rho0<-mclapply(1:length(d_l0),function(p){
    smap_res0<-block_lnlp(d_l0[[p]],method="s-map",
                          theta=rep(c(0,1e-04,3e-04,0.001,0.003,0.01,0.03,0.1,0.3,0.5,0.75,1,1.5,2,3,4,6,8),each=ncol(d_l0[[p]])-1),
                          silent=TRUE)
    rmse0<-tapply(as.numeric(smap_res0$rmse),smap_res0$theta,mean)
    p_val0<-tapply(as.numeric(smap_res0$p_val),smap_res0$theta,mean)
    rho0<-smap_res0$rho[paste("theta",names(rmse0)[which(rmse0==min(rmse0[complete.cases(p_val0)]))],sep="")]
    theta0<-as.numeric(names(rmse0)[which(rmse0==min(rmse0[complete.cases(p_val0)]))])
    smap.rho00<-data.frame(sp1=s1,sp2=paste(names(d_l0[[p]])[-1],collapse="-"),rho=rho0,theta=theta0)
    colnames(smap.rho00)<-c("To","From","rho","theta")
    return(smap.rho00)
  })
  smap.rho0<-do.call(rbind,smap.rho0)
  smap.rho<-rbind(smap.rho,smap.rho0)
  d_l<-c(d_l,d_l0)
}

tb01<-table(smap.rho$To)

wMc<-list()
for(s in 1:nrow(smap.rho)){
  s01<-smap.rho$To[s]
  s02<-smap.rho$From[s]
  d00<-d_l[[s]]
  if(nrow(d00)<nrow(data01)){
    b0<-data.frame(matrix(NA,nrow(data01)-nrow(d00),ncol(d00)))
    names(b0)<-names(d00)
    d00<-rbind(b0,d00)
  }
  dist0<-dist(d00[,-1],method="euclidean",diag=TRUE,upper=TRUE)
  weight<-smap.rho$rho[s]/sum(smap.rho$rho[smap.rho$To==s01])
  wMc[[s]]<-weight*dist0
}

dE<-list()
for(s in 1:length(unique(smap.rho$To))){
  sp01<-unique(smap.rho$To)[s]
  dE[[s]]<-Reduce("+",wMc[which(smap.rho$To==sp01)])
}

Wtk<-list()
for(i in 1:length(dE)){
  Wtk[[i]]<-as.data.frame(as.matrix(exp(-smap.rho$theta[i]*(dE[[i]]/mean(dE[[i]],na.rm=TRUE)))))
  Wtk[[i]]$time<-1:nrow(Wtk[[i]])
  Wtk[[i]]$sp<-unique(smap.rho$To)[i]
}

Wtk<-do.call(rbind,Wtk)
write.csv(Wtk,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/Wtk.csv",sep=""),row.names=FALSE)
Wtk<-read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/Wtk.csv',sep=""))

lambda0<-c(0,1e-04,3e-04,0.001,0.003,0.01,0.03,0.1,0.3,0.5,0.75,1,1.5,2,3,4,6,8)
alpha0<-seq(0,1,0.1)

MDR_s_map_coef<-list()
for(s in 1:length(unique(pairs[,1]))){
  if(is.na(pairs[pairs[,1]==unique(pairs[,1])[s],2])[1]){
    s1<-unique(pairs[,1])[s]
    d<-data.frame(cbind(data02,data03)[,s1])
    names(d)<-s1
    E1<-filter(params,species==s1)$E
    d00<-make_block(data.frame(t=1:nrow(d),d),max_lag=E1+1)
    d00<-d00[complete.cases(d00),]
    smap_res0<-block_lnlp(d00,method="s-map",
                          theta=rep(c(0,1e-04,3e-04,0.001,0.003,0.01,0.03,0.1,0.3,0.5,0.75,1,1.5,2,3,4,6,8),each=ncol(d00)-1),
                          silent=TRUE)
    rmse0<-tapply(as.numeric(smap_res0$rmse),smap_res0$theta,mean)
    p_val0<-tapply(as.numeric(smap_res0$p_val),smap_res0$theta,mean)
    thetay0<-as.numeric(names(rmse0)[which(rmse0==min(rmse0[complete.cases(p_val0)]))])
    smap.res<-block_lnlp(d00,method="s-map",theta=thetay0,silent=TRUE,
                         target_column=1,save_smap_coefficients=TRUE)
    smap.coef0<-as.data.frame(smap.res$smap_coefficients[[1]])[-1,-1]
    if(nrow(data01)>nrow(smap.coef0)){
      m0<-as.data.frame(matrix(NA,nrow(data01)-nrow(smap.coef0),ncol(smap.coef0)))
      colnames(m0)<-colnames(smap.coef0)
      smap.coef0<-rbind(m0,smap.coef0)
    }
    names(smap.coef0)[names(smap.coef0)=="C0"]<-"(Intercept)"
    names(smap.coef0)[grep(s1,names(smap.coef0))]<-paste(s1,"(t-",c(1:(E1)),")",sep="")
    coef0<-t(smap.coef0)
    MDR_s_map_coef[[s]]<-data.frame(sp1=s1,sp2=rownames(coef0),coef0)
    rownames(MDR_s_map_coef[[s]])<-c(1:nrow(coef0))
    colnames(MDR_s_map_coef[[s]])<-c("To","From",c(1:ncol(coef0)))
  }else{
    s1<-unique(pairs[,1])[s]
    s2<-unique(pairs[pairs[,1]==s1,2])
    d<-data.frame(cbind(data02,data03)[,s1])
    names(d)<-s1
    d0<-cbind(data01,data02,data03)
    d0<-data.frame(d0[,s2])
    names(d0)<-s2
    if(tb01[unique(pairs[,1])[s]]>1){
      d00<-cbind(d,c(NA,d[-nrow(d),]),d0)
      Wtk0<-Wtk[Wtk$sp==unique(pairs[,1])[s],1:nrow(data01)]
      ok<-apply(Wtk0[,1:nrow(data01)],1,sum,na.rm=TRUE)>0
      d00<-d00[ok,]
      Wtk0<-Wtk0[ok,ok]
      rmse0<-list()
      k<-0
      for(i in 1:length(lambda0)){
        for(j in 1:length(alpha0)){
          map<-apply(Wtk0,1,function(x){
            a<-svd(sqrt(x)*cbind(1,d00[,-1])+(lambda0[i]*(alpha0[j]*(norm(matrix(d00[,1]),"2")^2)+(1-alpha0[j]*norm(matrix(d00[,1]),"1")))))
            c<-a$v%*%diag(1/a$d,length(a$d),length(a$d))%*%t(a$u)
            c%*%(sqrt(x)*d00[,1])
          })
          k<-k+1
          rmse0[[k]]<-data.frame(rmse=sqrt(mean((d00[,1]-apply(cbind(1,d00[,-1])*t(map),1,sum))^2)),lambda=lambda0[i],alpha=alpha0[j])
        }
      }
      rmse0<-do.call(rbind,rmse0)
      lambda00<-rmse0$lambda[rmse0$rmse==min(rmse0$rmse)]
      alpha00<-rmse0$alpha[rmse0$rmse==min(rmse0$rmse)]
      coef0<-apply(Wtk0,1,function(x){
        a<-svd(sqrt(x)*cbind(1,d00[,-1])+(lambda00*(alpha00*(norm(matrix(d00[,1]),"2")^2)+(1-alpha00*norm(matrix(d00[,1]),"1")))))
        c<-a$v%*%diag(1/a$d,length(a$d),length(a$d))%*%t(a$u)
        c%*%(sqrt(x)*d00[,1])
      })
      if(nrow(data01)>ncol(coef0)){
        m0<-as.data.frame(matrix(NA,nrow(coef0),nrow(data01)-ncol(coef0)))
        rownames(m0)<-rownames(coef0)
        coef0<-cbind(m0,coef0)
      }
      MDR_s_map_coef[[s]]<-data.frame(sp1=s1,sp2=c(paste(s1,"(t-1)",sep=""),s2,"(Intercept)"),coef0)
      rownames(MDR_s_map_coef[[s]])<-c(1:nrow(coef0))
      colnames(MDR_s_map_coef[[s]])<-c("To","From",c(1:ncol(coef0)))
    }else{
      E1<-filter(params,species==s1)$E
      d00<-f_block(d,d0,E1)[[1]]
      smap_res0<-block_lnlp(d00,method="s-map",
                            theta=rep(c(0,1e-04,3e-04,0.001,0.003,0.01,0.03,0.1,0.3,0.5,0.75,1,1.5,2,3,4,6,8),each=ncol(d00)-1),
                            silent=TRUE)
      rmse0<-tapply(as.numeric(smap_res0$rmse),smap_res0$theta,mean)
      p_val0<-tapply(as.numeric(smap_res0$p_val),smap_res0$theta,mean)
      thetay0<-as.numeric(names(rmse0)[which(rmse0==min(rmse0[complete.cases(p_val0)]))])
      smap.res<-block_lnlp(d00,method="s-map",theta=thetay0,silent=TRUE,
                           target_column=1,save_smap_coefficients=TRUE)
      smap.coef0<-as.data.frame(smap.res$smap_coefficients[[1]])[-1,-1]
      if(nrow(data01)>nrow(smap.coef0)){
        m0<-as.data.frame(matrix(NA,nrow(data01)-nrow(smap.coef0),ncol(smap.coef0)))
        colnames(m0)<-colnames(smap.coef0)
        smap.coef0<-rbind(m0,smap.coef0)
      }
      names(smap.coef0)[names(smap.coef0)=="C0"]<-"(Intercept)"
      for(i in 1:length(s2)){
        names(smap.coef0)[grep(s2[i],names(smap.coef0))]<-s2[i]
      }
      if(E1>length(s2)){
        names(smap.coef0)[grep(s1,names(smap.coef0))]<-paste(s1,"(t-",c(1:(E1-length(s2))),")",sep="")
      }
      coef0<-t(smap.coef0)
      MDR_s_map_coef[[s]]<-data.frame(sp1=s1,sp2=rownames(coef0),coef0)
      rownames(MDR_s_map_coef[[s]])<-c(1:nrow(coef0))
      colnames(MDR_s_map_coef[[s]])<-c("To","From",c(1:ncol(coef0)))
    }
  }
}

MDR_s_map_coef<-do.call(rbind,MDR_s_map_coef)
write.csv(MDR_s_map_coef,file=paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S5.csv",sep=""),row.names=FALSE)
