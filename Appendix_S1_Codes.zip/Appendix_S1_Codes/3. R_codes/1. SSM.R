setwd("folderpass")

library(parallel)
library(dplyr)
library(tidyr)
library(cmdstanr)

levels_F<-c("Mean_water_level","Maximum_water_level")
levels_H<-c("Water_depth_SD","Current_velocity_SD","Sand","Granule","Pebble","Cobble","Boulder","Bedrock")
levels_S<-c("Andrias_japonicus","Cynops_pyrrhogaster","Oncorhynchus_masou",
            "Tribolodon_hakonensis","Rhynchocypris_oxycephalus","Nipponocypris_temminckii",
            "Pungtungia_herzi","Pseudogobio_esocinus","Cobitis_sp.",
            "Niwaella_delicata","Liobagrus_reinii","Cottus_pollux",
            "Odontobutis_obscura","Rhinogobius_flumineus")
levels_All<-c(levels_F,levels_H,levels_S)
levels_All<-c(levels_F,levels_H,levels_S)

levels_season<-c("December-January","February-March","April-May","June-July","August-September","October-November")

data01<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data02<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S2.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data03<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S3.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nhb<-length(levels_H)
nsp<-length(levels_S)

data01$Season<-factor(data01$Season,levels=levels_season)
data02$Season<-factor(data02$Season,levels=levels_season)
data03$Season<-factor(data03$Season,levels=levels_season)

data02[,levels_H]<-apply(data02[,levels_H],2,function(x)ifelse(x==9999,NA,x))
data03[,levels_S]<-apply(data03[,levels_S],2,function(x)ifelse(x==9999,NA,x))

data020<-as.data.frame(apply(data02[,levels_H],2,function(x){tapply(x,paste(data02$Year,as.numeric(data02$Season),sep="_"),mean,na.rm=TRUE)}))
data030<-as.data.frame(apply(data03[,levels_S],2,function(x){tapply(x,paste(data03$Year,as.numeric(data03$Season),sep="_"),function(x){round(mean(x,na.rm=TRUE),0)})}))

data020$Year<-data01$Year
data030$Year<-data01$Year
data020$Season<-data01$Season
data030$Season<-data01$Season

#Habitat conditions
fit<-list()
for(x in 1:nhb){
  Y<-data020[,levels_H[x]]
  Y<-ifelse(is.na(Y),9999,Y)
  Nmiss<-length(which(Y==9999))
  datastan <- list(N_sample=length(Y),
                   Y=Y,
                   Nmiss=Nmiss)
  model01<-readLines(paste(getwd(),"/Appendix_S1_Codes/2. Stan_codes/model_env01.stan",sep=""))
  if(x<=2){model01<-readLines(paste(getwd(),"/Appendix_S1_Codes/2. Stan_codes/model_env02.stan",sep=""))}
  iter0<-10000
  if(x==8){iter0<-20000}
  mod<-write_stan_file(model01)
  mod<-cmdstan_model(mod)
  fit0<-mod$sample(data=datastan,seed=1234,chains=4,parallel_chains=4,refresh=5000,iter_warmup=iter0,iter_sampling=iter0)
  fit[[x]]<-as.data.frame(fit0$summary())
}

sapply(fit,function(x){min(x$ess_bulk,na.rm=TRUE)})
sapply(fit,function(x){max(x$rhat,na.rm=TRUE)})

sample_fit<-list()
for(i in 1:nhb){
  v<-fit[[i]]$variable
  m<-fit[[i]]$median
  sample_fit[[i]]<-m[grep("\\<lambda01",v)]
}

data_fit_H<-as.data.frame(apply(do.call(cbind,sample_fit),2,function(x)round(x,3)))
colnames(data_fit_H)<-levels_H

#Populations
fit<-list()
for(x in c(1:nsp)){
  Y<-data030[,levels_S[x]]
  Y<-ifelse(is.na(Y),9999,Y)
  Nmiss<-length(which(Y==9999))
  Season_ID<-as.numeric(data01$Season)
  datastan <- list(N_sample=length(Y),
                   Y=Y,
                   Nmiss=Nmiss)
  model01<-readLines(paste(getwd(),"/Appendix_S1_Codes/2. Stan_codes/model_fish01.stan",sep=""))
  if(x == 9){model01<-readLines(paste(getwd(),"/Appendix_S1_Codes/2. Stan_codes/model_fish02.stan",sep=""))}
  iter0<-10000
  if(x == 14){iter0<-20000}
  mod<-write_stan_file(model01)
  mod<-cmdstan_model(mod)
  fit0<-mod$sample(data=datastan,seed=1234,chains=4,parallel_chains=4,refresh=5000,iter_warmup=iter0,iter_sampling=iter0)
  fit[[x]]<-as.data.frame(fit0$summary())
}

sapply(fit,function(x){min(x$ess_bulk,na.rm=TRUE)})
sapply(fit,function(x){max(x$rhat,na.rm=TRUE)})

sample_fit<-list()
for(i in 1:nsp){
  v<-fit[[i]]$variable
  m<-fit[[i]]$median
  sample_fit[[i]]<-m[grep("\\<lambda01",v)]
}

data_fit_S<-as.data.frame(apply(do.call(cbind,sample_fit),2,function(x)round(x,0)))
colnames(data_fit_S)<-levels_S

data_fit_HS<-cbind(data_fit_H,data_fit_S)
data_fit_HS$Year<-data01$Year
data_fit_HS$Season<-data01$Season

write.csv(data_fit_HS,file=paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),row.names=FALSE)
