setwd("folderpass")

library(parallel)
library(tibble)
library(patchwork)
library(ggExtra)
library(dplyr)
library(tidyr)
library(vegan)
library(rEDM)

levels_F<-c("Mean_water_level","Maximum_water_level")
levels_H<-c("Water_depth_SD","Current_velocity_SD","Sand","Granule","Pebble","Cobble","Boulder","Bedrock")
levels_S<-c("Andrias_japonicus","Cynops_pyrrhogaster","Oncorhynchus_masou",
            "Tribolodon_hakonensis","Rhynchocypris_oxycephalus","Nipponocypris_temminckii",
            "Pungtungia_herzi","Pseudogobio_esocinus","Cobitis_sp.",
            "Niwaella_delicata","Liobagrus_reinii","Cottus_pollux",
            "Odontobutis_obscura","Rhinogobius_flumineus")
levels_All<-c(levels_F,levels_H,levels_S)
levels_All<-c(levels_F,levels_H,levels_S)

levels_season<-c("December-January","February-March","April-May","June-July","August-September","October-November")

nhb<-length(levels_H)
nsp<-length(levels_S)

data01<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Data/1. Data_tables/Data_S1.csv',sep="")))
MDR_s_map_coef<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Data/1. Data_tables/Data_S5.csv',sep="")))
params2<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Codes/4. Parameters/Embedding_vertebrates.csv',sep="")))

smap.coef = MDR_s_map_coef %>% pivot_longer(c(-To,-From), names_to = "Time", values_to = "IS")
smap.coef$Time<-as.numeric(sub("X","",smap.coef$Time))

smap.coef_fish_fish<-smap.coef[is.element(smap.coef$From,levels_S),]
smap.coef_fish_habitat<-smap.coef[which(is.element(smap.coef$To,levels_S) & is.element(smap.coef$From,levels_H)),]
smap.nolag<-smap.coef[grep("t-1)",smap.coef$From,fixed=TRUE),]
smap.nolag<-smap.nolag[is.element(do.call(rbind,strsplit(smap.nolag$From,"\\("))[,1],levels_S),]
smap.lag<-smap.coef[grep("t-",smap.coef$From),]
smap.lag<-smap.lag[-grep("t-1)",smap.lag$From,fixed=TRUE),]
smap.lag<-smap.lag[is.element(do.call(rbind,strsplit(smap.lag$From,"\\("))[,1],levels_S),]

#The dynamic stability
eigen.all <- data.frame(matrix(NA, ncol = 1))
colnames(eigen.all) <- "max_s"
for(t in unique(smap.coef_fish_fish$Time)){
  tmp<-rbind(smap.coef_fish_fish,smap.nolag)
  tmp<-tmp[tmp$Time==t,]
  tmp$From<-sub("(t-1)","",tmp$From,fixed=TRUE)
  IS0<-matrix(0,length(unique(c(tmp$To,tmp$From))),length(unique(c(tmp$To,tmp$From))),dimnames=list(unique(c(tmp$To,tmp$From)),unique(c(tmp$To,tmp$From))))
  for(i in 1:length(unique(paste(tmp$To,tmp$From,sep="_")))){
    p<-strsplit(unique(paste(tmp$To,tmp$From,sep="__")),"__")[[i]]
    s1<-p[1]
    s2<-p[2]
    IS0[s1,s2]<-mean(filter(tmp,To==s1,From==s2)$IS)
  }
  if (any(is.na(IS0))) {
    eigen.all <- rbind(eigen.all, NA)
  } else{
    IS.top <- IS0
    tmp0<-smap.lag[smap.lag$Time==t,]
    for (i in 2:(max(params2$E) - 1)) {
      IS.temp0<-matrix(rep(0,length(IS0)),ncol=ncol(IS0))
      if(nrow(tmp0)>0){
        tmp00<-tmp0[grep(paste("t-",i,sep=""),tmp0$From),]
        for(s in 1:ncol(IS0)){
          IS.temp00<-as.numeric(tmp00$IS[grep(colnames(IS0)[s],sub(paste("(t-",i,")",sep=""),"",tmp00$From,fixed=TRUE))])
          if(length(IS.temp00)>0){IS.temp0[s,s]<-IS.temp00}
        }
      }
      IS.temp <- IS.temp0
      IS.top  <- cbind(IS.top,IS.temp)
    }
    cr.len  <- nrow(IS0)
    dim.is  <- max(params2$E) - 2
    unities <- diag(cr.len * dim.is)
    zeros   <- matrix(0, nrow = cr.len * dim.is, ncol = cr.len)
    IS.all  <- rbind(IS.top,cbind(unities, zeros))
    # Calculating eigenvalues
    ev <- eigen(IS.all)$values
    max.ev <- max(abs(ev))
    if (length(max.ev) == 1) eigen_tmp <- max.ev
    if (length(max.ev) != 1) eigen_tmp <- max.ev[1]
    names(eigen_tmp) <- "max_s"
    eigen.all <- rbind(eigen.all, eigen_tmp)
  }
}
eigen.all<-eigen.all[-1,]

#Mean of interaction strength
biotic<-tapply(abs(smap.coef_fish_fish$IS),as.factor(smap.coef_fish_fish$Time),mean)
#Mean of abiotic effects
abiotic<-tapply(abs(smap.coef_fish_habitat$IS),as.factor(smap.coef_fish_habitat$Time),mean)

data_interaction<-data.frame(Year=data01$Year,
                             Season=data01$Season,
                             Mean_biotic=biotic,
                             Mean_abiotic=abiotic,
                             Biotic_abiotic_ratio=biotic/abiotic,
                             Eigenvalue=eigen.all)
write.csv(data_interaction,file=paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S6.csv",sep=""),row.names=FALSE)

#Effect of floods on the interaction network
levels_I<-c("Eigenvalue","Mean_biotic","Mean_abiotic","Biotic_abiotic_ratio")

data02<-as.data.frame(read.csv(file=paste(getwd(),'/Appendix_S1_Data/1. Data_tables/Data_S1.csv',sep="")))
data03<-data_interaction

data02<-data02[,levels_F]
data03<-data03[,levels_I]

lm02<-apply(data02,2,function(x){lm(x~c(1:length(x)))})
lm03<-apply(data03,2,function(x){lm(x~c(1:length(x)))})

for(i in 1:ncol(data02)){if(summary(lm02[[i]])$coefficients[2,4]<0.05)data02[,i]<-residuals(lm02[[i]])}
for(i in 1:ncol(data03)){if(summary(lm03[[i]])$coefficients[2,4]<0.05)data03[!is.na(data03[,i]),i]<-residuals(lm03[[i]])}

data02<-as.data.frame(apply(data02,2,scale))
data03<-as.data.frame(apply(data03,2,scale))

#Optimal embedding dimensions
simplex2<-function(d01){
  Ey<-rep(NA,ncol(d01))
  thetay<-rep(NA,ncol(d01))
  for(s in 1:ncol(d01)){
    d <- d01[,s]
    simp_res<-simplex(d,E=1:15)
    E0<-as.numeric(simp_res$E)
    rmse0<-as.numeric(simp_res$rmse)
    p_val0<-as.numeric(simp_res$p_val)
    tau0<-as.factor(simp_res$tau)
    Ey[s] <- simp_res$E[which(rmse0==min(rmse0[complete.cases(p_val0)]))]
    smap_res2 <- s_map(d,E=Ey[s],silent=T)
    rmse0<-as.numeric(smap_res2$rmse)
    p_val0<-as.numeric(smap_res2$p_val)
    thetay[s]<-smap_res2$theta[which(rmse0==min(rmse0[complete.cases(p_val0)]))]
  }
  data.frame(species=colnames(d01),E=Ey,theta=thetay)
}

params3<-simplex2(data03[!is.na(data03$Eigenvalue),levels_I])
write.csv(params3,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/Embedding_network.csv",sep=""),row.names=FALSE)

#CCM
data_ccm<-function(d01,d02,params01){
  data_rho<-list()
  k<-0
  for(s1 in c(1:ncol(d02))){
    for(s2 in c(1:ncol(d01))){
      d<-cbind(d02[,s1],d01[,s2])
      libsize1<-c(params01$E[s1]+c(1,2),nrow(d)-(params01$E[s1]))
      n_surr<-100
      x1_surr<-make_surrogate_data(d[,1],method="seasonal",num_surr=n_surr,T_period=6)
      x2_surr<-make_surrogate_data(d[,2],method="seasonal",num_surr=n_surr,T_period=6)
      ccm_all_res <- ccm(d,E=params01$E[s1],
                         lib_sizes = libsize1,
                         stats_only = FALSE)
      ccm_pred<-ccm_all_res$CCM1_PredictStat
      rho1<-apply(matrix(ccm_pred$rho,ncol=length(libsize1)),2,quantile,probs=c(0.05,0.5,0.95))
      out1<-max(rho1[,2])<min(rho1[,length(libsize1)])
      if(out1){
        ccm_surr<-mclapply(1:n_surr, function(p) {
          ccm_surr0<-ccm(cbind(x1_surr[,p],x2_surr[,p]),
                         E=params01$E[s1],
                         lib_sizes = libsize1,
                         stats_only =TRUE)
          return(ccm_surr0$"X1:X2")
        }, mc.cores = 4)
        ccm_surr<-do.call(rbind,ccm_surr)
        rho2<-apply(ccm_surr,2,quantile,probs=c(0.05,0.5,0.95))
        out2<-max(rho2[,length(libsize1)])<min(rho1[,length(libsize1)])
        if(out2){
          k<-k+1
          rho12<-cbind(rho1[,-1],rho2[,-1])
          data_rho[[k]]<-data.frame(To=colnames(d02)[s1],From=colnames(d01)[s2],LibSize=rep(libsize1[-1],2),surr=rep(c("obs","surr"),each=length(libsize1[-1])),lower=rho12[1,],median=rho12[2,],upper=rho12[3,])
        }
      }
    }
  }
  ifelse(length(data_rho)==0,data_rho<-data.frame(To=NA,From=NA,LibSize=NA,surr=NA,lower=NA,median=NA,upper=NA),data_rho<-do.call(rbind,data_rho))
  data_rho
}

data_rho_IF<-data_ccm(data02[!is.na(data03$Eigenvalue),],data03[!is.na(data03$Eigenvalue),],params3)
write.csv(data_rho_IF,file=paste(getwd(),"/Appendix_S1_Codes/4. Parameters/rho_network_hydrologicals.csv",sep=""),row.names=FALSE)
