setwd("folderpass")

library(dplyr)
library(tidyr)
library(lubridate)
library(GGally)
library(ggplot2)
library(sna)
library(network)
levels_F<-c("Mean_water_level","Maximum_water_level")
levels_H<-c("Water_depth_SD","Current_velocity_SD","Sand","Granule","Pebble","Cobble","Boulder","Bedrock")
levels_S<-c("Andrias_japonicus","Cynops_pyrrhogaster","Oncorhynchus_masou",
            "Tribolodon_hakonensis","Rhynchocypris_oxycephalus","Nipponocypris_temminckii",
            "Pungtungia_herzi","Pseudogobio_esocinus","Cobitis_sp.",
            "Niwaella_delicata","Liobagrus_reinii","Cottus_pollux",
            "Odontobutis_obscura","Rhinogobius_flumineus")
levels_All<-c(levels_F,levels_H,levels_S)
levels_All<-c(levels_F,levels_H,levels_S)

levels_season<-c("December-January","February-March","April-May","June-July","August-September","October-November")

#Fig. 2
data01_0<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data01_0$Season<-factor(data01_0$Season,levels=levels_season)

D00<-ymd(paste(data01_0$Year,(as.numeric(data01_0$Season)*2),1,sep="-"))
D01<-D00-months(2)
rects<-data.frame(xstart=as.POSIXct(D01),xend=as.POSIXct(D00),col=rep(c("April-September (Warm season)","April-September (Warm season)","April-September (Warm season)","October-March (Cold season)","October-March (Cold season)","October-March (Cold season)"),100)[1:length(D01)])

data01 = data01_0 %>% pivot_longer(c(-Year,-Season), names_to = "Type", values_to = "WaterLevel")
data01<-data01[is.element(data01$Type,levels_F),]
data01$Date<-rep(D01+months(1),each=2)

g <- ggplot()
g <- g + 
  geom_rect(data=rects,aes(xmin=xstart,xmax=xend,ymin=-Inf,ymax=Inf,fill=col),alpha=0.1) +
  scale_fill_manual(values=c("#C0C0C0","#000000")) +
  geom_line(data=data01,aes(x=as.POSIXct(Date),y=WaterLevel,linetype=Type)) +
  scale_y_continuous(limits=c(0,3),expand=c(0,0)) +
  labs(x="",y="Water level (m)",linetype=NULL,fill=NULL) +
  theme_classic() +
  theme(legend.position="bottom",text=element_text(size=20)) +
  scale_linetype_discrete(guide="none")
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_2.pdf",sep=""),plot=g)

#Fig. 3
data030<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S5.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
or01<-c(5:24,1:4)
levels_All2<-levels_All[or01]

data03 = data030 %>% pivot_longer(c(-To,-From), names_to = "Time", values_to = "IS")
data03$Time<-as.numeric(sub("X","",data03$Time))
data03<-data03[-grep("(Intercept)",data03$From),]
data03<-data03[-grep("t-",data03$From),]

data03$To<-factor(as.character(data03$To),
                   levels=levels_All2)
data03$From<-factor(as.character(data03$From),
                   levels=levels_All2)

IS03<-matrix(0,length(levels_All),length(levels_All),dimnames=list(levels_All2,levels_All2))
IS03_min<-matrix(0,length(levels_All),length(levels_All),dimnames=list(levels_All2,levels_All2))
IS03_max<-matrix(0,length(levels_All),length(levels_All),dimnames=list(levels_All2,levels_All2))

for(i in 1:length(levels_All)){
for(j in 1:length(levels_All)){
  i03<-mean(abs(data03$IS)[data03$To==levels_All2[i] & data03$From==levels_All2[j]],na.rm=TRUE)
  i03_min<-min(data03$IS[data03$To==levels_All2[i] & data03$From==levels_All2[j]],na.rm=TRUE)
  i03_max<-max(data03$IS[data03$To==levels_All2[i] & data03$From==levels_All2[j]],na.rm=TRUE)
  if(!is.na(i03)){
    IS03[j,i]<-i03
    IS03_min[j,i]<-i03_min
    IS03_max[j,i]<-i03_max
  }
}}

col1<-c(rep("#000000",length(levels_F)),rep("#B0C4DE",length(levels_H)),rep("#808000",length(levels_S)))[or01]
col2<-rep("#808080",length(IS03))
col2<-ifelse(c(IS03_min)>0,"steelblue",col2)
col2<-ifelse(c(IS03_max)<0,"#B22222",col2)
col2<-col2[!c(IS03)==0]
size02<-abs(c(IS03))
size02<-size02[!c(IS03)==0]
size02<-as.numeric(as.character(cut(size02,br=c(-Inf,0.2,0.4,Inf),labels=c(0.2,1.0,2.0))))
label1<-c(1:length(levels_All))[or01]

g<-ggnet2(network(IS03,directed = TRUE),
            node.size=20,node.color=col1,
            edge.size=size02,edge.color=col2,
            arrow.size=6,arrow.gap=0.05,
            label=label1,label.size=10,label.color="white",
            mode="circle") + 
            theme(aspect.ratio=1)
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_3.pdf",sep=""),g)

#Fig. 4
data000<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S5.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #

data00 = data000 %>% pivot_longer(c(-To,-From), names_to = "Time", values_to = "IS")
data00$Time<-as.numeric(sub("X","",data00$Time))
data00<-data00[is.element(data00$To,levels_S),]
data00<-data00[-grep("(Intercept)",data00$From),]
data00<-data00[-grep("t-",data00$From),]

data00_0<-list()
p<-paste(data00$To,data00$From,sep="--")
s<-do.call(rbind,strsplit(unique(p),"--"))
for(i in c(1:length(unique(p)))){
  data00_0[[i]]<-data.frame(IS=mean(abs(data00$IS[p==unique(p)[i]]),na.rm=TRUE),
                            IS_min=min(data00$IS[p==unique(p)[i]],na.rm=TRUE),
                            IS_max=max(data00$IS[p==unique(p)[i]],na.rm=TRUE),
                            To=s[i,1],From=s[i,2])
}

data00_0<-do.call(rbind,data00_0)
data00_0$PN<-ifelse(data00_0$IS_min>0,"Positive","Changeable")
data00_0$PN<-ifelse(data00_0$IS_max<0,"Negative",data00_0$PN)
data00_0$PN<-factor(as.character(data00_0$PN),levels=c("Positive","Negative","Changeable"))
data00_0$Type<-ifelse(is.element(data00_0$From,c(levels_F,levels_H)),"(a) Abiotic","(b) Biotic")

table(data00_0$Type)
tapply(data00_0$IS,data00_0$Type,function(x)paste(round(mean(x),2),round(sd(x),2),sep=" ± "))
wilcox.test(data00_0$IS~data00_0$Type)

g <- ggplot(data00_0,aes(x=abs(IS), fill=PN))
g <- g + geom_histogram(position = "stack",binwidth=0.02) +
  scale_fill_manual(values=c("steelblue","#B22222","#808080")) +
  labs(x="",y="Counts") +
  theme_classic() +
  theme(legend.position="none",aspect.ratio=0.7,text=element_text(size=20)) +
  facet_wrap(~Type,nrow=2)
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_4.pdf",sep=""),g)

#Fig. 5
data000<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S6.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data000$Season<-factor(data000$Season,levels=levels_season)

D000<-ymd(paste(data000$Year,(as.numeric(data000$Season)*2),1,sep="-"))
D01<-D000-months(2)
rects<-data.frame(xstart=as.POSIXct(D01),xend=as.POSIXct(D000),col=rep(c("April-September (Warm season)","April-September (Warm season)","April-September (Warm season)","October-March (Cold season)","October-March (Cold season)","October-March (Cold season)"),1000)[1:length(D01)])
data000$Date<-D01+months(1)

data00 = data000[,c("Year","Season","Date","Eigenvalue")] %>% pivot_longer(c(-Year,-Season,-Date), names_to = "Type", values_to = "Value")

g <- ggplot() + 
  geom_rect(data=rects,aes(xmin=xstart,xmax=xend,ymin=-Inf,ymax=Inf,fill=col),alpha=0.2) +
  scale_fill_manual(values=c("#C0C0C0","#000000")) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_line(data=data00,aes(x=as.POSIXct(Date),y=Value)) +
  labs(x="",y="",fill=NULL) +
  theme_classic() +
  theme(legend.position="bottom",text=element_text(size=20))
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_5.pdf",sep=""),g)

#Fig. 6
data01<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data02<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S6.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #

s<-order(data01$Maximum_water_level,decreasing=TRUE)[1:3]
s<-s[order(s)]

data02$period<-NA
data02$elapsed_time<-NA
for(i in 1:length(s)){
  data02$period[s[i]:nrow(data02)]<-paste(data01$Season[s[i]],data01$Year[s[i]],sep=" ")
  data02$elapsed_time[s[i]:nrow(data02)]<-((1:(nrow(data02)-s[i]+1))-1)*2
}

data02_long = data02[!is.na(data02$period),c("Year","Season","period","elapsed_time","Mean_biotic","Biotic_abiotic_ratio","Eigenvalue")] %>% pivot_longer(c(-Year,-Season,-period,-elapsed_time), names_to = "Type", values_to = "Value")
data02_long$Type<-factor(data02_long$Type,levels=c("Mean_biotic","Biotic_abiotic_ratio","Eigenvalue"),labels=c("(a) Mean interaction strength","(b) Biotic:abiotic ratio","(c) Dynamic stability"))
data02_long$period<-factor(data02_long$period,levels=unique(data02_long$period),labels=c("April 2011","August 2013","October 2017"))

summary(lm(Mean_biotic~elapsed_time,data=data02))
summary(lm(Biotic_abiotic_ratio~elapsed_time,data=data02))
summary(lm(Eigenvalue~elapsed_time,data=data02))

g<-ggplot(data=data02_long)
g<-g +
  geom_line(aes(x=elapsed_time,y=Value,linetype=period)) +
  labs(x="Elapsed time (month)",y="Value",linetype=NULL) +
  facet_wrap(~Type,scales="free_y",nrow=2) + 
  theme_classic() +
  theme(legend.position="bottom",text=element_text(size=20))
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_6.pdf",sep=""),g)

#Fig. S1
data02_1<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S2.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data02_2<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nhb<-length(levels_H)

data02_1$Season<-factor(data02_1$Season,levels=levels_season)
D01<-ymd(paste(data02_1$Year,(as.numeric(data02_1$Season)*2),1,sep="-"))-months(1)

data02_1<-data02_1[,levels_H]
data02_2<-data02_2[,levels_H]


data02_1$Date<-as.POSIXct(D01)
data02_2$Date<-as.POSIXct(unique(D01))

data02_1l = data02_1 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")
data02_1l<-subset(data02_1l,!value==9999)
data02_2l = data02_2 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")

data02_1l$Type<-factor(as.character(data02_1l$Type),
                       levels=levels_H)
data02_2l$Type<-factor(as.character(data02_2l$Type),
                      levels=levels_H)
col0<-"Observed values"

g<-ggplot() +
  geom_point(data=data02_1l,aes(x=Date,y=value,colour=col0)) +
  scale_colour_manual(values=c("#C0C0C0")) +
  geom_line(data=data02_2l,aes(x=Date,y=value)) +
  labs(x="Year",y="Value",linetype="",colour="") +
  facet_wrap(~Type,scales="free_y") +
  theme_classic() +
  theme(legend.position="bottom")
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_S1.pdf",sep=""),g)

#Fig. S2
data03_1<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S3.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data03_2<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nsp<-length(levels_S)

data03_1$Season<-factor(data03_1$Season,levels=levels_season)
D01<-ymd(paste(data03_1$Year,(as.numeric(data03_1$Season)*2),1,sep="-"))-months(1)

data03_1<-data03_1[,levels_S]
data03_2<-data03_2[,levels_S]

data03_1$Date<-as.POSIXct(D01)
data03_2$Date<-as.POSIXct(unique(D01))

data03_1l = data03_1 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")
data03_1l<-subset(data03_1l,!value==9999)
data03_2l = data03_2 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")

data03_1l$Type<-factor(as.character(data03_1l$Type),
                       levels=levels_S)
data03_2l$Type<-factor(as.character(data03_2l$Type),
                      levels=levels_S)
col0<-"Observed values"

g<-ggplot() +
  geom_point(data=data03_1l,aes(x=Date,y=value,colour=col0)) +
  scale_colour_manual(values=c("#C0C0C0")) +
  geom_line(data=data03_2l,aes(x=Date,y=value)) +
  labs(x="Year",y="Counts",linetype="",colour="") +
  facet_wrap(~Type,scales="free_y") +
  theme_classic() +
  theme(legend.position="bottom")
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_S2.pdf",sep=""),g)
