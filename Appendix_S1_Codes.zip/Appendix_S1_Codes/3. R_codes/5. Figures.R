setwd("folderpass")

library(dplyr)
library(tidyr)
library(lubridate)
library(GGally)
library(ggplot2)
library(gridExtra)
library(sna)
library(network)
library(vegan)

levels_F<-c("Mean_water_level","Maximum_water_level")
levels_H<-c("Water_depth_SD","Current_velocity_SD","Sand","Granule","Pebble","Cobble","Boulder","Bedrock")
levels_S<-c("Andrias_japonicus","Cynops_pyrrhogaster","Oncorhynchus_masou",
            "Tribolodon_hakonensis","Rhynchocypris_oxycephalus","Nipponocypris_temminckii",
            "Pungtungia_herzi","Pseudogobio_esocinus","Cobitis_sp.",
            "Niwaella_delicata","Liobagrus_reinii","Cottus_pollux",
            "Odontobutis_obscura","Rhinogobius_flumineus")
levels_All<-c(levels_F,levels_H,levels_S)
levels_All<-c(levels_F,levels_H,levels_S)

levels_season<-c("December-January","February-March","April-May","June-July","August-September","October-November")

#Fig. 2
data01_0<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data01_0$Season<-factor(data01_0$Season,levels=levels_season)

D00<-ymd(paste(data01_0$Year,(as.numeric(data01_0$Season)*2),1,sep="-"))
D01<-D00-months(2)
rects<-data.frame(xstart=as.POSIXct(D01),xend=as.POSIXct(D00),col=rep(c("April-September (Warm season)","April-September (Warm season)","April-September (Warm season)","October-March (Cold season)","October-March (Cold season)","October-March (Cold season)"),100)[1:length(D01)])

data01 = data01_0 %>% pivot_longer(c(-Year,-Season), names_to = "Type", values_to = "WaterLevel")
data01<-data01[is.element(data01$Type,levels_F),]
data01$Date<-rep(D01+months(1),each=2)

g <- ggplot()
g <- g + 
  geom_rect(data=rects,aes(xmin=xstart,xmax=xend,ymin=-Inf,ymax=Inf,fill=col),alpha=0.1) +
  scale_fill_manual(values=c("#C0C0C0","#000000")) +
  geom_line(data=data01,aes(x=as.POSIXct(Date),y=WaterLevel,linetype=Type)) +
  scale_y_continuous(limits=c(0,3),expand=c(0,0)) +
  labs(x="",y="Water level (m)",linetype=NULL,fill=NULL) +
  theme_classic() +
  theme(legend.position="bottom",text=element_text(size=20)) +
  scale_linetype_discrete(guide="none")
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_2.pdf",sep=""),plot=g)

#Fig. 3
data030<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S5.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
or01<-c(5:24,1:4)
levels_All2<-levels_All[or01]

data03 = data030 %>% pivot_longer(c(-To,-From), names_to = "Time", values_to = "IS")
data03$Time<-as.numeric(sub("X","",data03$Time))
data03<-data03[-grep("(Intercept)",data03$From),]
data03<-data03[-grep("t-",data03$From),]

data03$To<-factor(as.character(data03$To),
                   levels=levels_All2)
data03$From<-factor(as.character(data03$From),
                   levels=levels_All2)

IS03<-matrix(0,length(levels_All),length(levels_All),dimnames=list(levels_All2,levels_All2))
IS03_min<-matrix(0,length(levels_All),length(levels_All),dimnames=list(levels_All2,levels_All2))
IS03_max<-matrix(0,length(levels_All),length(levels_All),dimnames=list(levels_All2,levels_All2))

for(i in 1:length(levels_All)){
for(j in 1:length(levels_All)){
  i03<-mean(abs(data03$IS)[data03$To==levels_All2[i] & data03$From==levels_All2[j]],na.rm=TRUE)
  i03_min<-min(data03$IS[data03$To==levels_All2[i] & data03$From==levels_All2[j]],na.rm=TRUE)
  i03_max<-max(data03$IS[data03$To==levels_All2[i] & data03$From==levels_All2[j]],na.rm=TRUE)
  if(!is.na(i03)){
    IS03[j,i]<-i03
    IS03_min[j,i]<-i03_min
    IS03_max[j,i]<-i03_max
  }
}}

col1<-c(rep("#000000",length(levels_F)),rep("#B0C4DE",length(levels_H)),rep("#808000",length(levels_S)))[or01]
col2<-rep("#808080",length(IS03))
col2<-ifelse(c(IS03_min)>0,"steelblue",col2)
col2<-ifelse(c(IS03_max)<0,"#B22222",col2)
col2<-col2[!c(IS03)==0]
size02<-abs(c(IS03))
size02<-size02[!c(IS03)==0]
size02<-as.numeric(as.character(cut(size02,br=c(-Inf,0.2,0.4,0.8,Inf),labels=c(0.2,1.0,2.0,3.0))))
label1<-c(1:length(levels_All))[or01]

g<-ggnet2(network(IS03,directed = TRUE),
            node.size=20,node.color=col1,
            edge.size=size02,edge.color=col2,
            arrow.size=6,arrow.gap=0.05,
            label=label1,label.size=10,label.color="white",
            mode="circle") + 
            theme(aspect.ratio=1)
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_3.pdf",sep=""),g)

#Fig. 4
data000<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S5.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data0<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #

s<-order(data0$Maximum_water_level,decreasing=TRUE)[1:3]
s<-s[order(s)]

data00 = data000 %>% pivot_longer(c(-To,-From), names_to = "Time", values_to = "IS")
data00$Time<-as.numeric(sub("X","",data00$Time))
data00<-data00[is.element(data00$To,levels_S),]
data00<-data00[-grep("(Intercept)",data00$From),]
data01<-data00[-grep("t-",data00$From),]
d02<-data00[grep("t-",data00$From),]
d002<-as.data.frame(tapply(d02$IS,list(d02$To,as.factor(d02$Time)),sum))
d002$To<-rownames(d002)
d002$From<-rownames(d002)
d002_long<-d002 %>% pivot_longer(c(-To,-From), names_to = "Time", values_to = "IS")
d002_long$Time<-as.numeric(sub("X","",d002_long$Time))
data02<-d002_long
data02<-data02[!data02$To=="Cobitis_sp.",]
data01$Pair<-paste(data01$To,data01$From,sep="_")
data02$Pair<-paste(data02$To,data02$From,sep="_")
data01$Type<-ifelse(is.element(data01$From,c(levels_F,levels_H)),"(e) Abiotic","(b) Interspecific interaction (All pairs)")
data02$Type<-"(a) Intraspecific interaction (All pairs)"
data03<-data01[!is.element(data01$Pair,unique(data01$Pair[abs(data01$IS)>2])),]
unique(data01$Pair[is.element(data01$Pair,unique(data01$Pair[abs(data01$IS)>2]))])
data03$Type<-"(d) Interspecific interaction (< |2|)"
data04<-data02[!is.element(data02$Pair,unique(data02$Pair[abs(data02$IS)>2])),]
unique(data02$Pair[is.element(data02$Pair,unique(data02$Pair[abs(data02$IS)>2]))])
data04$Type<-"(c) Intraspecific interaction (< |2|)"
data01<-rbind(data01[complete.cases(data01$IS),],
              data02[complete.cases(data02$IS),],
              data03[complete.cases(data03$IS),],
              data04[complete.cases(data04$IS),])
data001<-data01[is.element(data01$Type,c("(a) Intraspecific interaction (All pairs)","(b) Interspecific interaction (All pairs)")),]
data002<-data01[is.element(data01$Type,c("(c) Intraspecific interaction (< |2|)","(d) Interspecific interaction (< |2|)","(e) Abiotic")),]

d1<-data.frame(x=s,y=max(data01$IS,na.rm=TRUE))
d2<-data.frame(x=s,y=max(data04$IS,na.rm=TRUE))

g1 <- ggplot() +
  geom_hline(yintercept=0,linetype="dashed") +
  geom_line(data=data001,aes(x=Time,y=IS,color=Pair)) +
  geom_point(data=d1,aes(x=x,y=y),shape=6) +
  facet_wrap(~Type,ncol=3) + 
  labs(x="Time",y="") +
  theme_classic() +
  theme(legend.position="none",aspect.ratio=1,text=element_text(size=11))
g2 <- ggplot() +
  geom_hline(yintercept=0,linetype="dashed") +
  geom_line(data=data002,aes(x=Time,y=IS,color=Pair)) +
  geom_point(data=d2,aes(x=x,y=y),shape=6) +
  facet_wrap(~Type,ncol=3) + 
  labs(x="Time",y="") +
  theme_classic() +
  theme(legend.position="none",aspect.ratio=1,text=element_text(size=11))
g<-grid.arrange(g1,g2,nrow=2)
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_4.pdf",sep=""),g)

data01_0<-list()
p<-paste(data01$To,data01$From,sep="--")
s<-do.call(rbind,strsplit(unique(p),"--"))
for(i in c(1:length(unique(p)))){
  data01_0[[i]]<-data.frame(IS=mean(abs(data01$IS[p==unique(p)[i]]),na.rm=TRUE),
                            To=s[i,1],From=s[i,2])
}

data01_0<-do.call(rbind,data01_0)
data01_0$Type<-ifelse(is.element(data01_0$From,c(levels_F,levels_H)),"(a) Abiotic","(b) Interspecific interaction")
data01_0$Type[data01_0$To==data01_0$From]<-"(c) Intraspecific interaction"

table(data01_0$Type)
tapply(data01_0$IS,data01_0$Type,function(x)paste(round(mean(x),2),round(sd(x),2),sep=" ± "))
pairwise.wilcox.test(data01_0$IS,data01_0$Type,p.adj="bonferroni")

#Fig. 5
data000<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S6.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data0<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #

ok<-complete.cases(data000)
data000<-data000[ok,]
data0<-data0[ok,]
data000$Season<-factor(data000$Season,levels=levels_season)

s<-order(data0$Maximum_water_level,decreasing=TRUE)[1:3]
s<-s[order(s)]

D000<-ymd(paste(data000$Year,(as.numeric(data000$Season)*2),1,sep="-"))
D01<-D000-months(2)
rects<-data.frame(xstart=as.POSIXct(D01),xend=as.POSIXct(D000),col=rep(c("April-September (Warm season)","April-September (Warm season)","April-September (Warm season)","October-March (Cold season)","October-March (Cold season)","October-March (Cold season)"),1000)[1:length(D01)])
data000$Date<-D01+months(1)

data001 = data000[,c("Year","Season","Date","Eigenvalue")] %>% pivot_longer(c(-Year,-Season,-Date), names_to = "Type", values_to = "Value")
data002 = data000[,c("Year","Season","Date","Mean_biotic")] %>% pivot_longer(c(-Year,-Season,-Date), names_to = "Type", values_to = "Value")
data003 = data000[,c("Year","Season","Date","Self_regulation")] %>% pivot_longer(c(-Year,-Season,-Date), names_to = "Type", values_to = "Value")

data00<-rbind(data001,data002,data003)
data00<-data00[complete.cases(data00),]
data00$Type<-factor(data00$Type,levels=c("Self_regulation","Mean_biotic","Eigenvalue"),labels=c("(a) Intraspecific interaction","(b) Interspecific interaction","(c) Local Lyapunov stability"))

d1<-data.frame(y=c(NA,NA,1),Type=c("(a) Intraspecific interaction","(b) Interspecific interaction","(c) Local Lyapunov stability"))

d2<-data.frame(x=rep(data000$Date[s],3),y=rep(c(max(data000$Self_regulation,na.rm=TRUE),max(data000$Mean_biotic,na.rm=TRUE),max(data000$Eigenvalue,na.rm=TRUE)),each=3),Type=rep(c("(a) Intraspecific interaction","(b) Interspecific interaction","(c) Local Lyapunov stability"),each=3))

g <- ggplot() + 
  geom_rect(data=rects,aes(xmin=xstart,xmax=xend,ymin=-Inf,ymax=Inf,fill=col),alpha=0.2) +
  scale_fill_manual(values=c("#C0C0C0","#000000")) +
  geom_hline(data=d1,aes(yintercept=y),linetype="dashed") +
  geom_point(data=d2,aes(x=as.POSIXct(x),y=y),shape=6) +
  geom_line(data=data00,aes(x=as.POSIXct(Date),y=Value)) +
  facet_wrap(~Type,scales="free_y",nrow=3) +
  labs(x="",y="",fill=NULL) +
  theme_classic() +
  theme(legend.position="bottom",aspect.ratio=0.3,text=element_text(size=16))
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_5.pdf",sep=""),g)

#Fig. 6
data01<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S1.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data02<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S6.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #

s<-order(data01$Maximum_water_level,decreasing=TRUE)[1:3]
s<-s[order(s)]

data02$period<-NA
data02$elapsed_time<-NA
for(i in 1:length(s)){
  data02$period[s[i]:nrow(data02)]<-paste(data01$Season[s[i]],data01$Year[s[i]],sep=" ")
  data02$elapsed_time[s[i]:nrow(data02)]<-((1:(nrow(data02)-s[i]+1))-1)*2
}

data02_long = data02[!is.na(data02$period),c("Year","Season","period","elapsed_time","Species_richness","Self_regulation","Mean_biotic","Total_self","Total_biotic","Intra_inter_ratio","Biotic_abiotic_ratio","Eigenvalue")] %>% pivot_longer(c(-Year,-Season,-period,-elapsed_time), names_to = "Type", values_to = "Value")
data02_long$Type<-factor(data02_long$Type,levels=c("Species_richness","Self_regulation","Mean_biotic","Total_self","Total_biotic","Intra_inter_ratio","Biotic_abiotic_ratio","Eigenvalue"),labels=c("(a) Species richness","(b) Intraspecific interaction (absolute mean)","(c) Interspecific interaction (absolute mean)","(d) Intraspecific interaction (simple mean)","(e) Interspecific interaction (simple mean)","(f) Intra:inter ratio","(g) Biotic:abiotic ratio","(h) Local Lyapunov stability"))
data02_long$period<-factor(data02_long$period,levels=unique(data02_long$period),labels=c("April 2011","August 2013","October 2018"))
data02_long$Season<-factor(data02_long$Season,levels=levels_season)

lm01<-list(lm(Species_richness~elapsed_time+Season,data=data02),
           lm(Self_regulation~elapsed_time+Season,data=data02),
           lm(Mean_biotic~elapsed_time+Season,data=data02),
           lm(Total_self~elapsed_time+Season,data=data02),
           lm(Total_biotic~elapsed_time+Season,data=data02),
           lm(Intra_inter_ratio~elapsed_time+Season,data=data02),
           lm(Biotic_abiotic_ratio~elapsed_time+Season,data=data02),
           lm(Eigenvalue~elapsed_time+Season,data=data02))
lapply(lm01,summary)
lm01_pr0<-lapply(lm01,predict,type="response",se.fit=TRUE,
                 newdata=data.frame(elapsed_time=seq(0,50,5),Season=levels_season[3]))
lm01_pr<-list()
for(i in 1:length(lm01_pr0)){
  lm01_pr[[i]]<-data.frame(Value=lm01_pr0[[i]]$fit,
                           elapsed_time=seq(0,50,5),
                           upper=lm01_pr0[[i]]$fit + qt(0.025, df = lm01_pr0[[i]]$df) * lm01_pr0[[i]]$se.fit,
                           lower=lm01_pr0[[i]]$fit + qt(0.975, df = lm01_pr0[[i]]$df) * lm01_pr0[[i]]$se.fit,
                           Season=levels_season[3],
                           Type=c("Species_richness","Self_regulation","Mean_biotic","Total_self","Total_biotic","Intra_inter_ratio","Biotic_abiotic_ratio","Eigenvalue")[i])
}
lm01_pr<-do.call(rbind,lm01_pr)
lm01_pr$Type<-factor(lm01_pr$Type,levels=c("Species_richness","Self_regulation","Mean_biotic","Total_self","Total_biotic","Intra_inter_ratio","Biotic_abiotic_ratio","Eigenvalue"),labels=c("(a) Species richness","(b) Intraspecific interaction (absolute mean)","(c) Interspecific interaction (absolute mean)","(d) Intraspecific interaction (simple mean)","(e) Interspecific interaction (simple mean)","(f) Intra:inter ratio","(g) Biotic:abiotic ratio","(h) Local Lyapunov stability"))
lm01_pr$Season<-factor(lm01_pr$Season,levels=levels_season)

g<-ggplot(data=data02_long)
g<-g +
  geom_smooth(data=lm01_pr,aes(x=elapsed_time,y=Value,ymin=lower,ymax=upper),stat='identity') +
  geom_line(aes(x=elapsed_time,y=Value,linetype=period)) +
  labs(x="Elapsed time (month)",y="Value",linetype=NULL) +
  facet_wrap(~Type,scales="free_y",nrow=3) + 
  theme_classic() +
  theme(legend.position="bottom",aspect.ratio=0.6,text=element_text(size=9))
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_6.pdf",sep=""),g)

#Fig. 7
data01<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data02<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S5.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #

data01_1<-data01[,levels_H]
data01_2<-data01[,levels_S]
data02<-t(data02[which(is.element(data02$To,levels_S) & is.element(data02$From,levels_S)),grep("X",names(data02))])

ok<-complete.cases(apply(data02,1,sum))

data01_1<-data01_1[ok,]
data01_2<-data01_2[ok,]
data02<-data02[ok,]

abiotic_pca<-princomp(data01_1)
summary(abiotic_pca)
biotic_mds<-metaMDS(data01_2,k=2,distance="bray")
MDS<-cmdscale(vegdist(data01_2,method="bray"),k =2,eig=T,add=T)
round(MDS$eig*100/sum(MDS$eig),1)
interaction_pca<-princomp(data02)
summary(interaction_pca)

abiotic<-abiotic_pca$scores[,2]
biotic<-biotic_mds$points[,2]
interaction<-interaction_pca$scores[,2]

lm01<-lm(interaction~abiotic)
lm02<-lm(interaction~biotic)
lm03<-lm(interaction~abiotic*biotic)
summary(lm01)
summary(lm02)
summary(lm03)

d<-data.frame(
  Time=rep(1:length(interaction),2),
  Interaction=rep(interaction,2),
  Explanatory=c(abiotic,biotic),
  Type=rep(c("Abiotic condition","Species composition"),each=length(interaction))
)
d$Type<-factor(d$Type,levels=c("Abiotic condition","Species composition"))

g<-ggplot(data=d)
g<-g +
  geom_path(aes(x=Explanatory,y=Interaction),color="grey") +
  geom_smooth(method="lm",se=TRUE,aes(x=Explanatory,y=Interaction),size=2,color="black") +
  labs(x="",y="State of interaction matrix") +
  facet_wrap(~Type,scale="free_x",nrow=2) + 
  theme_classic() +
  theme(aspect.ratio=0.7,text=element_text(size=20))
ggsave(paste(getwd(),file="/Appendix_S1_Codes/5. Figures/Fig_7.pdf",sep=""),g)

#Fig. S1
data02_1<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S2.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data02_2<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nhb<-length(levels_H)

data02_1$Season<-factor(data02_1$Season,levels=levels_season)
D01<-ymd(paste(data02_1$Year,(as.numeric(data02_1$Season)*2),1,sep="-"))-months(1)

data02_1<-data02_1[,levels_H]
data02_2<-data02_2[,levels_H]


data02_1$Date<-as.POSIXct(D01)
data02_2$Date<-as.POSIXct(unique(D01))

data02_1l = data02_1 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")
data02_1l<-subset(data02_1l,!value==9999)
data02_2l = data02_2 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")

data02_1l$Type<-factor(as.character(data02_1l$Type),
                       levels=levels_H)
data02_2l$Type<-factor(as.character(data02_2l$Type),
                      levels=levels_H)
col0<-"Observed values"

g<-ggplot() +
  geom_point(data=data02_1l,aes(x=Date,y=value,colour=col0)) +
  scale_colour_manual(values=c("#C0C0C0")) +
  geom_line(data=data02_2l,aes(x=Date,y=value)) +
  labs(x="Year",y="Value",linetype="",colour="") +
  facet_wrap(~Type,scales="free_y") +
  theme_classic() +
  theme(legend.position="bottom")
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_S1.pdf",sep=""),g)

#Fig. S2
data03_1<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S3.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
data03_2<-read.csv(file(paste(getwd(),"/Appendix_S1_Data/1. Data_tables/Data_S4.csv",sep=""),encoding="UTF8"),header=TRUE,sep=",")  #
nsp<-length(levels_S)

data03_1$Season<-factor(data03_1$Season,levels=levels_season)
D01<-ymd(paste(data03_1$Year,(as.numeric(data03_1$Season)*2),1,sep="-"))-months(1)

data03_1<-data03_1[,levels_S]
data03_2<-data03_2[,levels_S]

data03_1$Date<-as.POSIXct(D01)
data03_2$Date<-as.POSIXct(unique(D01))

data03_1l = data03_1 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")
data03_1l<-subset(data03_1l,!value==9999)
data03_2l = data03_2 %>% pivot_longer(c(-Date), names_to = "Type", values_to = "value")

data03_1l$Type<-factor(as.character(data03_1l$Type),
                       levels=levels_S)
data03_2l$Type<-factor(as.character(data03_2l$Type),
                      levels=levels_S)
col0<-"Observed values"

g<-ggplot() +
  geom_point(data=data03_1l,aes(x=Date,y=value,colour=col0)) +
  scale_colour_manual(values=c("#C0C0C0")) +
  geom_line(data=data03_2l,aes(x=Date,y=value)) +
  labs(x="Year",y="Counts",linetype="",colour="") +
  facet_wrap(~Type,scales="free_y") +
  theme_classic() +
  theme(legend.position="bottom")
ggsave(paste(getwd(),"/Appendix_S1_Codes/5. Figures/Fig_S2.pdf",sep=""),g)
